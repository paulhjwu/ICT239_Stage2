pip install Flask
pip install dnspython
pip install pymongo
pip install flask-login
pip install flask-mail
export LC_ALL=C.UTF-8
LANG=C.UTF-8
FLASK_DEBUG=1