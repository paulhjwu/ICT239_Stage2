from flask import Flask, request, render_template, jsonify, url_for
import math

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['GET', 'POST'])
def process():

    if request.method == 'GET':
        return render_template("index.html")

    elif request.method == 'POST':
        #pass        #make sure js and css files are loaded
        weight  = float(request.form['weight'])
        height = float(request.form['height'])
        unit = request.form['unit']

        if unit == 'm':
            bmi = weight / math.pow(height, 2)
        else:
            bmi = weight / math.pow(height/100, 2)

        print('BMI 1: {}'.format(bmi))
        return jsonify({'bmi' : bmi})
        #return {'bmi' : bmi}

#if __name__ == "__main__":
app.run(debug=True, host='0.0.0.0')